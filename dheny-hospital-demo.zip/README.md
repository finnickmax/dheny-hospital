# Dheny Hospital - SIMRS Demo

## How to Run Locally
1. Run `npm install`
2. Run `npm run dev`
3. Open `http://localhost:3000`

## Login Demo
- Username: demo
- Password: demo123