export default function Dashboard() {
  return (
    <div style={{ padding: 40 }}>
      <h1>Dheny Hospital Dashboard</h1>
      <ul>
        <li>Rawat Jalan</li>
        <li>Farmasi</li>
        <li>Billing</li>
        <li>Rekam Medis</li>
      </ul>
    </div>
  )
}