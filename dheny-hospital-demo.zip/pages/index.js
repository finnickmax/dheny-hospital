export default function Home() {
  return (
    <div style={{ padding: 40 }}>
      <h1>Welcome to Dheny Hospital SIMRS Demo</h1>
      <p>This is a landing page showcasing SIMRS features including BPJS and SATUSEHAT integration.</p>
      <a href="/login">Try Demo Login</a>
    </div>
  )
}